# Data-Engineering-Workshop
Dataset with different type of source to test Data Engineering capability.
The Dataset consist of 3 source:
- a CSV file
- a Json log file
- a txt file with the link to Google Bigquery database
